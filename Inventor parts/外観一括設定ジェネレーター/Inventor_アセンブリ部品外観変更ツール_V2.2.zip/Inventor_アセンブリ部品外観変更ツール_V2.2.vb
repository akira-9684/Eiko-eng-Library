﻿AddReference "System.Windows.Forms"
AddReference "System.Drawing"
AddReference "stdole"

Imports System.Windows.Forms
Imports System.Drawing
Imports Inventor
Imports System.Collections.Generic

Sub Main()

    If ThisApplication.ActiveDocument Is Nothing Then
        System.Windows.Forms.MessageBox.Show(
            "ドキュメントが開かれていません。",
            "部品外観変更",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning)
        Exit Sub
    End If

    If ThisApplication.ActiveDocument.DocumentType <> _
       DocumentTypeEnum.kAssemblyDocumentObject Then

        System.Windows.Forms.MessageBox.Show(
            "このプログラムはアセンブリ専用です。" & vbCrLf &
            "アセンブリ（.iam）を開いて実行してください。",
            "部品外観変更",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information)
        Exit Sub
    End If

    Dim asmDoc As AssemblyDocument =
        CType(ThisApplication.ActiveDocument, AssemblyDocument)

    Dim frm As New AppearanceManagerForm(asmDoc, ThisApplication)
    frm.ShowDialog()

End Sub


'============================================================
' Inventor アセンブリ 部品外観変更ツール
' Version 2.2
'
' ・アセンブリ専用
' ・各パーツごとに個別の外観を指定
' ・「変更しない」を選択した行は処理しない
' ・「元の外観」を選択するとパーツ本来の外観へ戻す
' ・.ipt ファイル自体の外観は変更しない
' ・アセンブリ内 ComponentOccurrence の外観だけを変更
'============================================================

Public Class PictureConverter
    Inherits System.Windows.Forms.AxHost

    Private Sub New()
        MyBase.New("")
    End Sub

    Public Shared Function ToImage(
        ByVal picture As stdole.IPictureDisp) As System.Drawing.Image

        If picture Is Nothing Then Return Nothing

        Return System.Windows.Forms.AxHost.GetPictureFromIPicture(
            picture)

    End Function
End Class


Public Class AppearanceManagerForm
    Inherits System.Windows.Forms.Form

    Private Const NO_CHANGE As String = "（変更しない）"
    Private Const ORIGINAL_APPEARANCE As String = "（元の外観）"

    Private _asmDoc As AssemblyDocument
    Private _app As Inventor.Application

    Private lblTitle As System.Windows.Forms.Label
    Private lblSearch As System.Windows.Forms.Label
    Private txtSearch As System.Windows.Forms.TextBox
    Private grid As System.Windows.Forms.DataGridView

    Private btnApply As System.Windows.Forms.Button
    Private btnResetSelected As System.Windows.Forms.Button
    Private btnClearSettings As System.Windows.Forms.Button
    Private btnRemoveFavorite As System.Windows.Forms.Button
    Private btnClose As System.Windows.Forms.Button

    Private lblInfo As System.Windows.Forms.Label
    Private lblCount As System.Windows.Forms.Label

    Private allOccurrences As New List(Of ComponentOccurrence)

    ' 表示名 -> 外観Asset
    ' 文書内Assetを優先し、無ければライブラリAssetを保持する
    Private appearanceSources As New Dictionary(
        Of String, Asset)(StringComparer.CurrentCultureIgnoreCase)

    Private appearanceNames As New List(Of String)

    '========================================================
    ' 外観のお気に入り
    ' ・部品ではなく外観名を保存
    ' ・お気に入り外観はプルダウン上位へ表示
    ' ・全アセンブリ共通
    '========================================================
    Private favoriteAppearanceNames As New HashSet(
        Of String)(StringComparer.CurrentCultureIgnoreCase)

    Private pendingSettings As New Dictionary(
        Of String, String)(StringComparer.OrdinalIgnoreCase)

    Private _favoritesFile As String = ""

    ' お気に入り表示用フォントを再利用
    Private _favoriteFont As System.Drawing.Font = Nothing

    ' Inventor実サムネイルのキャッシュ
    ' Key = 外観DisplayName
    Private _thumbnailCache As New Dictionary(
        Of String, System.Drawing.Bitmap)(
        StringComparer.CurrentCultureIgnoreCase)

    ' 一度取得に失敗した外観は繰り返し試さない
    Private _thumbnailFailed As New HashSet(
        Of String)(
        StringComparer.CurrentCultureIgnoreCase)

    ' 外観検索用
    Private _isRebuilding As Boolean = False


    Public Sub New(
        ByVal asmDoc As AssemblyDocument,
        ByVal app As Inventor.Application)

        _asmDoc = asmDoc
        _app = app

        Me.Text = "アセンブリ 部品外観変更 V2.2"
        Me.Width = 980
        Me.Height = 700
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.Sizable
        Me.MinimumSize = New System.Drawing.Size(850, 580)

        ' 高DPI環境での表示崩れを軽減
        Me.AutoScaleMode =
            System.Windows.Forms.AutoScaleMode.Dpi

        _favoriteFont =
            New System.Drawing.Font(
                Me.Font,
                System.Drawing.FontStyle.Bold)

        CreateControls()
        LoadAppearanceList()
        LoadOccurrences()

        _favoritesFile = GetFavoritesFilePath()
        LoadFavorites()

        ' お気に入りを反映して外観プルダウンを再構築
        ConfigureAppearanceComboColumn()

        FillGrid("")

        AddHandler Me.FormClosed,
            AddressOf AppearanceManagerFormClosed

    End Sub


    '========================================================
    ' UI
    '========================================================
    Private Sub CreateControls()

        lblTitle = New System.Windows.Forms.Label()
        lblTitle.Text = "アセンブリ 部品外観変更"
        lblTitle.Font = New System.Drawing.Font(
            "Yu Gothic UI", 16, FontStyle.Bold)
        lblTitle.Left = 20
        lblTitle.Top = 15
        lblTitle.Width = 500
        lblTitle.Height = 35
        Me.Controls.Add(lblTitle)

        lblSearch = New System.Windows.Forms.Label()
        lblSearch.Text = "外観検索"
        lblSearch.Left = 20
        lblSearch.Top = 65
        lblSearch.Width = 70
        Me.Controls.Add(lblSearch)

        txtSearch = New System.Windows.Forms.TextBox()
        txtSearch.Left = 95
        txtSearch.Top = 60
        txtSearch.Width = 485
        txtSearch.Anchor =
            AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        AddHandler txtSearch.TextChanged, AddressOf SearchChanged
        Me.Controls.Add(txtSearch)

        lblCount = New System.Windows.Forms.Label()
        lblCount.Left = 600
        lblCount.Top = 65
        lblCount.Width = 330
        lblCount.TextAlign = ContentAlignment.MiddleRight
        lblCount.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Me.Controls.Add(lblCount)

        grid = New System.Windows.Forms.DataGridView()
        grid.Left = 20
        grid.Top = 100
        grid.Width = 925
        grid.Height = 445
        grid.Anchor =
            AnchorStyles.Top Or AnchorStyles.Bottom Or
            AnchorStyles.Left Or AnchorStyles.Right

        grid.AllowUserToAddRows = False
        grid.AllowUserToDeleteRows = False
        grid.AllowUserToResizeRows = False
        grid.RowHeadersVisible = False
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        grid.MultiSelect = True
        grid.AutoGenerateColumns = False
        grid.EditMode = DataGridViewEditMode.EditOnEnter

        Dim colOcc As New DataGridViewTextBoxColumn()
        colOcc.Name = "Occurrence"
        colOcc.HeaderText = "配置部品"
        colOcc.ReadOnly = True
        colOcc.Width = 245

        Dim colFile As New DataGridViewTextBoxColumn()
        colFile.Name = "FileName"
        colFile.HeaderText = "パーツファイル"
        colFile.ReadOnly = True
        colFile.Width = 230

        Dim colCurrent As New DataGridViewTextBoxColumn()
        colCurrent.Name = "CurrentAppearance"
        colCurrent.HeaderText = "現在の外観"
        colCurrent.ReadOnly = True
        colCurrent.Width = 170

        Dim colSwatch As New DataGridViewImageColumn()
        colSwatch.Name = "AppearanceSwatch"
        colSwatch.HeaderText = "外観画像"
        colSwatch.Width = 44
        colSwatch.ImageLayout = DataGridViewImageCellLayout.Normal
        colSwatch.ReadOnly = True

        Dim colNew As New DataGridViewComboBoxColumn()
        colNew.Name = "NewAppearance"
        colNew.HeaderText = "設定する外観"
        colNew.Width = 185
        colNew.FlatStyle = FlatStyle.Flat
        colNew.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton

        Dim colFavorite As New DataGridViewCheckBoxColumn()
        colFavorite.Name = "Favorite"
        colFavorite.HeaderText = "外観お気に入り"
        colFavorite.Width = 96
        colFavorite.ReadOnly = False
        colFavorite.SortMode = DataGridViewColumnSortMode.NotSortable

        grid.Columns.Add(colOcc)
        grid.Columns.Add(colFile)
        grid.Columns.Add(colCurrent)
        grid.Columns.Add(colSwatch)
        grid.Columns.Add(colNew)
        grid.Columns.Add(colFavorite)

        AddHandler grid.CellValueChanged, AddressOf GridCellValueChanged
        AddHandler grid.CurrentCellDirtyStateChanged, AddressOf GridCurrentCellDirtyStateChanged
        AddHandler grid.CurrentCellChanged, AddressOf GridCurrentCellChanged
        AddHandler grid.EditingControlShowing, AddressOf GridEditingControlShowing
        AddHandler grid.DataError, AddressOf GridDataError

        Me.Controls.Add(grid)

        btnApply = New System.Windows.Forms.Button()
        btnApply.Text = "設定した外観を適用"
        btnApply.Left = 20
        btnApply.Top = 560
        btnApply.Width = 190
        btnApply.Height = 42
        btnApply.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        AddHandler btnApply.Click, AddressOf ApplyClicked
        Me.Controls.Add(btnApply)

        btnResetSelected = New System.Windows.Forms.Button()
        btnResetSelected.Text = "選択行を元の外観に戻す"
        btnResetSelected.Left = 225
        btnResetSelected.Top = 560
        btnResetSelected.Width = 215
        btnResetSelected.Height = 42
        btnResetSelected.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        AddHandler btnResetSelected.Click, AddressOf ResetSelectedClicked
        Me.Controls.Add(btnResetSelected)

        btnClearSettings = New System.Windows.Forms.Button()
        btnClearSettings.Text = "設定をクリア"
        btnClearSettings.Left = 455
        btnClearSettings.Top = 560
        btnClearSettings.Width = 125
        btnClearSettings.Height = 42
        btnClearSettings.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        AddHandler btnClearSettings.Click, AddressOf ClearSettingsClicked
        Me.Controls.Add(btnClearSettings)

        btnRemoveFavorite = New System.Windows.Forms.Button()
        btnRemoveFavorite.Text = "選択外観のお気に入り解除"
        btnRemoveFavorite.Left = 595
        btnRemoveFavorite.Top = 560
        btnRemoveFavorite.Width = 200
        btnRemoveFavorite.Height = 42
        btnRemoveFavorite.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        AddHandler btnRemoveFavorite.Click, AddressOf RemoveFavoriteClicked
        Me.Controls.Add(btnRemoveFavorite)

        btnClose = New System.Windows.Forms.Button()
        btnClose.Text = "閉じる"
        btnClose.Left = 805
        btnClose.Top = 560
        btnClose.Width = 140
        btnClose.Height = 42
        btnClose.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        AddHandler btnClose.Click, AddressOf CloseClicked
        Me.Controls.Add(btnClose)

        lblInfo = New System.Windows.Forms.Label()
        lblInfo.Text =
            "※ Inventor実サムネイルを表示し、取得できない外観は代表色表示へ切り替えます。" & vbCrLf &
            "※ お気に入り外観は上位に表示し、プルダウン内で「★＋太字＋青文字」で表示します。"
        lblInfo.Left = 20
        lblInfo.Top = 615
        lblInfo.Width = 925
        lblInfo.Height = 45
        lblInfo.Anchor =
            AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        lblInfo.ForeColor = System.Drawing.Color.DarkRed
        Me.Controls.Add(lblInfo)

    End Sub


    '========================================================
    ' 外観一覧を取得
    ' 1) アセンブリ文書内
    ' 2) Inventorの外観ライブラリ
    '========================================================
    Private Sub LoadAppearanceList()

        appearanceSources.Clear()
        appearanceNames.Clear()

        '-----------------------------------------------
        ' アセンブリ文書内の外観
        '-----------------------------------------------
        Try
            For Each a As Asset In _asmDoc.Assets

                If a.AssetType =
                   AssetTypeEnum.kAssetTypeAppearance Then

                    AddAppearanceSource(a)
                End If

            Next
        Catch
        End Try

        '-----------------------------------------------
        ' Inventorに登録されている外観ライブラリ
        '-----------------------------------------------
        Try
            For Each assetLib As AssetLibrary In _app.AssetLibraries

                Try
                    For Each a As Asset In assetLib.AppearanceAssets
                        AddAppearanceSource(a)
                    Next
                Catch
                    ' 読めないライブラリは無視
                End Try

            Next
        Catch
        End Try

        appearanceNames.AddRange(appearanceSources.Keys)
        appearanceNames.Sort(StringComparer.CurrentCultureIgnoreCase)

    End Sub


    Private Sub AddAppearanceSource(ByVal a As Asset)

        Try
            Dim nm As String = a.DisplayName

            If String.IsNullOrWhiteSpace(nm) Then Exit Sub

            ' 既に存在する場合は文書内Assetを優先する
            If Not appearanceSources.ContainsKey(nm) Then
                appearanceSources.Add(nm, a)
            Else
                Try
                    If a.Parent Is _asmDoc Then
                        appearanceSources(nm) = a
                    End If
                Catch
                End Try
            End If

        Catch
        End Try

    End Sub


    '========================================================
    ' 外観プルダウンを共通化
    '
    ' 各行ごとに外観候補を作ると、外観数×部品数だけ
    ' 項目生成が発生して非常に重くなる。
    ' DataGridViewComboBoxColumn側に一度だけ登録する。
    '========================================================
    Private Sub ConfigureAppearanceComboColumn()

        Try

            Dim col As DataGridViewComboBoxColumn =
                CType(grid.Columns("NewAppearance"),
                      DataGridViewComboBoxColumn)

            col.Items.Clear()

            ' 常用項目
            col.Items.Add(NO_CHANGE)
            col.Items.Add(ORIGINAL_APPEARANCE)

            '----------------------------------------------
            ' お気に入り外観を上位へ
            '----------------------------------------------
            Dim favorites As New List(Of String)
            Dim normals As New List(Of String)

            For Each nm As String In appearanceNames

                If favoriteAppearanceNames.Contains(nm) Then
                    favorites.Add(nm)
                Else
                    normals.Add(nm)
                End If

            Next

            favorites.Sort(StringComparer.CurrentCultureIgnoreCase)
            normals.Sort(StringComparer.CurrentCultureIgnoreCase)

            For Each nm As String In favorites
                col.Items.Add(nm)
            Next

            For Each nm As String In normals
                col.Items.Add(nm)
            Next

        Catch ex As Exception

            System.Windows.Forms.MessageBox.Show(
                "外観リストの設定中にエラーが発生しました。" &
                vbCrLf & ex.Message,
                "部品外観変更",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning)

        End Try

    End Sub


    '========================================================
    ' Occurrence取得
    '========================================================
    Private Sub LoadOccurrences()

        allOccurrences.Clear()

        Try
            Dim leafOccs As ComponentOccurrencesEnumerator =
                _asmDoc.ComponentDefinition.Occurrences.AllLeafOccurrences

            For Each occ As ComponentOccurrence In leafOccs

                Try
                    If occ.DefinitionDocumentType =
                       DocumentTypeEnum.kPartDocumentObject Then

                        allOccurrences.Add(occ)
                    End If
                Catch
                End Try

            Next

        Catch ex As Exception

            System.Windows.Forms.MessageBox.Show(
                "部品一覧の取得中にエラーが発生しました。" &
                vbCrLf & ex.Message,
                "エラー",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)
        End Try

    End Sub


    '========================================================
    ' グリッド表示
    '========================================================
    Private Sub FillGrid(ByVal filterText As String)

        If _isRebuilding Then Exit Sub

        _isRebuilding = True

        Try

            SavePendingSettingsFromGrid()

            grid.SuspendLayout()
            DisposeAllSwatchBitmaps()
            grid.Rows.Clear()

            Dim visibleCount As Integer = 0

            '------------------------------------------------
            ' 部品一覧は常にInventorから取得した順番で表示。
            ' 検索欄では部品一覧を絞り込まない。
            '------------------------------------------------
            For Each occ As ComponentOccurrence In allOccurrences

                Dim fileName As String = GetPartFileName(occ)

                Dim rowIndex As Integer = grid.Rows.Add()
                Dim row As DataGridViewRow = grid.Rows(rowIndex)
                row.Tag = occ

                row.Cells("Occurrence").Value = occ.Name
                row.Cells("FileName").Value = fileName
                row.Cells("CurrentAppearance").Value =
                    GetOccurrenceAppearanceName(occ)

                Dim key As String = OccurrenceKey(occ)
                Dim selectedAppearance As String = NO_CHANGE

                If pendingSettings.ContainsKey(key) Then
                    selectedAppearance = pendingSettings(key)
                End If

                row.Cells("NewAppearance").Value =
                    selectedAppearance

                row.Cells("Favorite").Value =
                    IsFavoriteAppearance(selectedAppearance)

                UpdateSwatchForRow(row)
                visibleCount += 1

            Next

            lblCount.Text =
                "表示：" & visibleCount &
                " / 全部品：" & allOccurrences.Count &
                " / お気に入り外観：" &
                favoriteAppearanceNames.Count

        Catch ex As Exception

            System.Windows.Forms.MessageBox.Show(
                "一覧の更新中にエラーが発生しました。" &
                vbCrLf & ex.Message,
                "部品外観変更",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning)

        Finally

            Try
                grid.ResumeLayout()
            Catch
            End Try

            _isRebuilding = False

        End Try

    End Sub


    Private Sub SavePendingSettingsFromGrid()

        If grid Is Nothing Then Exit Sub

        For Each r As DataGridViewRow In grid.Rows

            Try
                Dim occ As ComponentOccurrence =
                    CType(r.Tag, ComponentOccurrence)

                If occ Is Nothing Then Continue For

                Dim selectedText As String =
                    Convert.ToString(
                        r.Cells("NewAppearance").Value)

                If String.IsNullOrWhiteSpace(selectedText) Then
                    selectedText = NO_CHANGE
                End If

                pendingSettings(OccurrenceKey(occ)) =
                    selectedText

            Catch
            End Try

        Next

    End Sub


    Private Function OccurrenceKey(
        ByVal occ As ComponentOccurrence) As String

        Try
            Return occ.Name & "|" & GetPartFullFileName(occ)
        Catch
            Return occ.Name
        End Try

    End Function


    Private Function GetPartFullFileName(
        ByVal occ As ComponentOccurrence) As String

        Try
            Dim partDoc As PartDocument =
                CType(occ.Definition.Document, PartDocument)

            Return partDoc.FullFileName
        Catch
            Return ""
        End Try

    End Function


    Private Function GetPartFileName(
        ByVal occ As ComponentOccurrence) As String

        Try
            Dim fullName As String = GetPartFullFileName(occ)

            If fullName <> "" Then
                Return System.IO.Path.GetFileName(fullName)
            End If

            Return "(未保存)"
        Catch
            Return "(取得不可)"
        End Try

    End Function


    Private Function GetOccurrenceAppearanceName(
        ByVal occ As ComponentOccurrence) As String

        Try
            If occ.Appearance IsNot Nothing Then
                Return occ.Appearance.DisplayName
            End If
        Catch
        End Try

        Return "(取得不可)"

    End Function


    '========================================================
    ' 外観をアセンブリ文書内Assetとして取得
    ' ライブラリAssetなら CopyTo で文書にコピー
    '========================================================
    Private Function GetAssemblyAppearanceAsset(
        ByVal appearanceName As String) As Asset

        ' 既にアセンブリ文書内にある場合
        Try
            For Each a As Asset In _asmDoc.Assets

                If a.AssetType =
                   AssetTypeEnum.kAssetTypeAppearance AndAlso
                   String.Equals(
                       a.DisplayName,
                       appearanceName,
                       StringComparison.CurrentCultureIgnoreCase) Then

                    Return a
                End If

            Next
        Catch
        End Try

        If Not appearanceSources.ContainsKey(appearanceName) Then
            Return Nothing
        End If

        Dim src As Asset = appearanceSources(appearanceName)

        ' ライブラリなどからアセンブリ文書へコピー
        Try
            Dim copied As Asset = src.CopyTo(_asmDoc)

            If copied IsNot Nothing Then
                appearanceSources(appearanceName) = copied
                Return copied
            End If
        Catch
        End Try

        ' コピー済みになっている可能性があるので再検索
        Try
            For Each a As Asset In _asmDoc.Assets

                If a.AssetType =
                   AssetTypeEnum.kAssetTypeAppearance AndAlso
                   String.Equals(
                       a.DisplayName,
                       appearanceName,
                       StringComparison.CurrentCultureIgnoreCase) Then

                    appearanceSources(appearanceName) = a
                    Return a
                End If

            Next
        Catch
        End Try

        Return Nothing

    End Function


    '========================================================
    ' パーツ本来の外観をアセンブリ文書へコピーして取得
    ' .ipt は変更しない
    '========================================================
    '========================================================
    ' 元のパーツ外観をプレビュー用に取得
    '
    ' 重要：
    ' この関数ではAssembly文書へCopyToしない。
    ' 色スウォッチ表示のために文書Assetが増える副作用を防ぐ。
    '========================================================
    Private Function GetOriginalPartAppearanceForPreview(
        ByVal occ As ComponentOccurrence) As Asset

        Try
            Dim partDoc As PartDocument =
                CType(occ.Definition.Document, PartDocument)

            Return partDoc.ActiveAppearance

        Catch
            Return Nothing
        End Try

    End Function


    Private Function GetOriginalPartAppearance(
        ByVal occ As ComponentOccurrence) As Asset

        ' この関数は実際にOccurrenceへ元外観を適用する時だけ使用する。
        ' 必要に応じてPart側AssetをAssemblyへCopyToするため、
        ' プレビュー用途では呼ばないこと。


        Try
            Dim partDoc As PartDocument =
                CType(occ.Definition.Document, PartDocument)

            Dim originalAsset As Asset = partDoc.ActiveAppearance

            If originalAsset Is Nothing Then Return Nothing

            ' 同名Assetがアセンブリにあれば使用
            Dim localAsset As Asset =
                GetAssemblyAppearanceAsset(originalAsset.DisplayName)

            If localAsset IsNot Nothing Then
                Return localAsset
            End If

            ' パーツ文書のAssetをアセンブリへコピー
            Try
                Return originalAsset.CopyTo(_asmDoc)
            Catch
                Return Nothing
            End Try

        Catch
            Return Nothing
        End Try

    End Function


    '========================================================
    ' 「設定する外観」プルダウンのお気に入り表示
    '
    ' お気に入り外観：
    '   ★マーク + 太字 + 青文字
    '
    ' 通常外観：
    '   通常文字
    '
    ' ※ 表示だけを変更し、実際の外観名は変更しない。
    '========================================================
    '========================================================
    ' DataGridViewComboBoxCell 安全対策
    '========================================================
    Private Sub GridDataError(
        ByVal sender As Object,
        ByVal e As DataGridViewDataErrorEventArgs)

        ' 候補一覧の再構築中に一時的に値が候補外になる場合がある。
        ' 標準エラーダイアログは出さず、現在値を候補へ戻す。
        Try

            If e.RowIndex >= 0 AndAlso
               e.ColumnIndex >= 0 AndAlso
               grid.Columns(e.ColumnIndex).Name = "NewAppearance" Then

                Dim row As DataGridViewRow =
                    grid.Rows(e.RowIndex)

                Dim cell As DataGridViewComboBoxCell =
                    TryCast(
                        row.Cells("NewAppearance"),
                        DataGridViewComboBoxCell)

                If cell IsNot Nothing Then

                    Dim currentText As String =
                        Convert.ToString(cell.Value)

                    If currentText <> "" AndAlso
                       Not cell.Items.Contains(currentText) Then

                        cell.Items.Insert(0, currentText)

                    End If

                End If

            End If

        Catch
        End Try

        e.ThrowException = False

    End Sub


    Private Function GetOrderedAppearanceNames(
        ByVal searchText As String) As List(Of String)

        Dim favorites As New List(Of String)
        Dim normals As New List(Of String)

        Dim filterText As String =
            If(searchText, "").Trim()

        For Each nm As String In appearanceNames

            If filterText <> "" AndAlso
               nm.IndexOf(
                   filterText,
                   StringComparison.CurrentCultureIgnoreCase) < 0 Then

                Continue For

            End If

            If favoriteAppearanceNames.Contains(nm) Then
                favorites.Add(nm)
            Else
                normals.Add(nm)
            End If

        Next

        favorites.Sort(
            StringComparer.CurrentCultureIgnoreCase)

        normals.Sort(
            StringComparer.CurrentCultureIgnoreCase)

        Dim result As New List(Of String)
        result.AddRange(favorites)
        result.AddRange(normals)

        Return result

    End Function


    Private Sub PopulateAppearanceCell(
        ByVal cell As DataGridViewComboBoxCell,
        ByVal currentValue As String,
        ByVal searchText As String)

        If cell Is Nothing Then Exit Sub

        cell.Items.Clear()
        cell.Items.Add(NO_CHANGE)
        cell.Items.Add(ORIGINAL_APPEARANCE)

        For Each nm As String In
            GetOrderedAppearanceNames(searchText)

            cell.Items.Add(nm)

        Next

        ' 現在値は必ず候補内に残す。
        If currentValue <> "" AndAlso
           Not cell.Items.Contains(currentValue) Then

            cell.Items.Insert(0, currentValue)

        End If

        If currentValue = "" Then
            currentValue = NO_CHANGE
        End If

        cell.Value = currentValue

    End Sub


    Private Sub RefreshAppearanceComboAfterFavoriteChange()

        If grid Is Nothing Then Exit Sub

        '====================================================
        ' V2.0
        ' お気に入り変更時に全行×全外観を再構築しない。
        '
        ' 1. 列の共通候補を1回だけ並べ替える
        ' 2. 現在選択中のセルだけ検索条件を反映して再構築する
        '
        ' 大規模アセンブリでのフリーズ防止。
        '====================================================
        Try

            SavePendingSettingsFromGrid()

            ConfigureAppearanceComboColumn()

            If grid.CurrentRow IsNot Nothing Then
                ApplyAppearanceSearchToSelectedRow()
            End If

            RefreshFavoriteChecks()

        Catch
        End Try

    End Sub


    Private Sub GridEditingControlShowing(
        ByVal sender As Object,
        ByVal e As DataGridViewEditingControlShowingEventArgs)

        Try

            If grid.CurrentCell Is Nothing Then Exit Sub

            If grid.Columns(grid.CurrentCell.ColumnIndex).Name <>
               "NewAppearance" Then
                Exit Sub
            End If

            Dim cmb As System.Windows.Forms.ComboBox =
                TryCast(e.Control, System.Windows.Forms.ComboBox)

            If cmb Is Nothing Then Exit Sub

            ' 同じEditingControlが再利用されるため、
            ' 多重登録を防止してから登録する。
            RemoveHandler cmb.DrawItem,
                AddressOf AppearanceComboDrawItem

            cmb.DrawMode =
                System.Windows.Forms.DrawMode.OwnerDrawFixed

            cmb.ItemHeight = Math.Max(
                cmb.Font.Height + 4,
                20)

            AddHandler cmb.DrawItem,
                AddressOf AppearanceComboDrawItem

        Catch
        End Try

    End Sub


    Private Sub AppearanceComboDrawItem(
        ByVal sender As Object,
        ByVal e As System.Windows.Forms.DrawItemEventArgs)

        If e.Index < 0 Then Exit Sub

        Dim cmb As System.Windows.Forms.ComboBox =
            TryCast(sender, System.Windows.Forms.ComboBox)

        If cmb Is Nothing Then Exit Sub

        Dim itemText As String =
            Convert.ToString(cmb.Items(e.Index))

        Dim isFavorite As Boolean =
            IsFavoriteAppearance(itemText)

        e.DrawBackground()

        Dim foreColor As System.Drawing.Color

        If (e.State And
            System.Windows.Forms.DrawItemState.Selected) =
            System.Windows.Forms.DrawItemState.Selected Then

            foreColor = e.ForeColor

        ElseIf isFavorite Then

            foreColor = System.Drawing.Color.RoyalBlue

        Else

            foreColor = e.ForeColor

        End If

        Dim drawFont As System.Drawing.Font = cmb.Font

        Try

            If isFavorite Then

                If _favoriteFont Is Nothing Then
                    _favoriteFont =
                        New System.Drawing.Font(
                            cmb.Font,
                            System.Drawing.FontStyle.Bold)
                End If

                drawFont = _favoriteFont

            End If

            Dim x As Single =
                CSng(e.Bounds.Left + 4)

            Dim y As Single =
                CSng(e.Bounds.Top +
                     Math.Max(
                         0,
                         (e.Bounds.Height -
                          drawFont.Height) \ 2))

            ' お気に入りは★を先頭に表示
            If isFavorite Then

                Dim starText As String = "★"

                Using starBrush As New System.Drawing.SolidBrush(
                    foreColor)

                    e.Graphics.DrawString(
                        starText,
                        drawFont,
                        starBrush,
                        x,
                        y)

                End Using

                Dim starSize As System.Drawing.SizeF =
                    e.Graphics.MeasureString(
                        starText,
                        drawFont)

                x += starSize.Width + 2

            End If

            Using textBrush As New System.Drawing.SolidBrush(
                foreColor)

                e.Graphics.DrawString(
                    itemText,
                    drawFont,
                    textBrush,
                    x,
                    y)

            End Using

        Finally
            ' ブラシはUsingで都度破棄。
            ' 太字フォントはフォーム終了時にまとめて破棄する。
        End Try

        e.DrawFocusRectangle()

    End Sub


    Private Sub GridCurrentCellChanged(
        ByVal sender As Object,
        ByVal e As EventArgs)

        If _isRebuilding Then Exit Sub
        If grid.CurrentRow Is Nothing Then Exit Sub

        ' 行を選び直した場合、その行の外観リストに
        ' 現在の検索条件を適用する。
        ApplyAppearanceSearchToSelectedRow()

    End Sub


    Private Sub GridCurrentCellDirtyStateChanged(
        ByVal sender As Object,
        ByVal e As EventArgs)

        If _isRebuilding Then Exit Sub

        If grid.IsCurrentCellDirty Then
            grid.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If

    End Sub


    Private Sub GridCellValueChanged(
        ByVal sender As Object,
        ByVal e As DataGridViewCellEventArgs)

        If _isRebuilding Then Exit Sub
        If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then Exit Sub

        Dim columnName As String =
            grid.Columns(e.ColumnIndex).Name

        If columnName = "NewAppearance" Then

            Try
                Dim row As DataGridViewRow =
                    grid.Rows(e.RowIndex)

                Dim occ As ComponentOccurrence =
                    CType(row.Tag, ComponentOccurrence)

                Dim selectedAppearance As String =
                    Convert.ToString(
                        row.Cells("NewAppearance").Value)

                If occ IsNot Nothing Then
                    pendingSettings(OccurrenceKey(occ)) =
                        selectedAppearance
                End If

                ' 外観を変更したら、その外観のお気に入り状態を表示
                row.Cells("Favorite").Value =
                    IsFavoriteAppearance(selectedAppearance)

                UpdateSwatchForRow(row)

            Catch
            End Try

        ElseIf columnName = "Favorite" Then

            Try
                Dim row As DataGridViewRow =
                    grid.Rows(e.RowIndex)

                Dim selectedAppearance As String =
                    Convert.ToString(
                        row.Cells("NewAppearance").Value)

                ' 「変更しない」「元の外観」はお気に入り対象外
                If Not CanFavoriteAppearance(selectedAppearance) Then

                    _isRebuilding = True
                    row.Cells("Favorite").Value = False
                    _isRebuilding = False

                    Exit Sub
                End If

                Dim isFavorite As Boolean =
                    Convert.ToBoolean(
                        row.Cells("Favorite").Value)

                If isFavorite Then
                    favoriteAppearanceNames.Add(
                        selectedAppearance)
                Else
                    favoriteAppearanceNames.Remove(
                        selectedAppearance)
                End If

                SaveFavorites()

                ' 現在値を保持したまま全プルダウンを安全に再構築
                SavePendingSettingsFromGrid()
                RefreshAppearanceComboAfterFavoriteChange()
                RefreshFavoriteChecks()

                lblCount.Text =
                    "表示：" & grid.Rows.Count &
                    " / 全部品：" & allOccurrences.Count &
                    " / お気に入り外観：" &
                    favoriteAppearanceNames.Count

            Catch
                _isRebuilding = False
            End Try

        End If

    End Sub


    Private Sub DisposeSwatchBitmap(
        ByVal row As DataGridViewRow)

        If row Is Nothing Then Exit Sub

        Try
            Dim oldBmp As System.Drawing.Bitmap =
                TryCast(
                    row.Cells("AppearanceSwatch").Value,
                    System.Drawing.Bitmap)

            If oldBmp IsNot Nothing Then
                row.Cells("AppearanceSwatch").Value = Nothing
                oldBmp.Dispose()
            End If
        Catch
        End Try

    End Sub


    Private Sub DisposeAllSwatchBitmaps()

        If grid Is Nothing Then Exit Sub

        For Each row As DataGridViewRow In grid.Rows
            DisposeSwatchBitmap(row)
        Next

    End Sub


    Private Sub SetSwatchBitmap(
        ByVal row As DataGridViewRow,
        ByVal bmp As System.Drawing.Bitmap)

        DisposeSwatchBitmap(row)
        row.Cells("AppearanceSwatch").Value = bmp

    End Sub


    Private Sub UpdateSwatchForRow(
        ByVal row As DataGridViewRow)

        Try
            Dim setting As String =
                Convert.ToString(
                    row.Cells("NewAppearance").Value)

            '----------------------------------------------
            ' 変更しない：空表示
            '----------------------------------------------
            If String.IsNullOrWhiteSpace(setting) OrElse
               setting = NO_CHANGE Then

                SetSwatchBitmap(
                    row,
                    CreateColorSwatch(
                        System.Drawing.Color.Transparent))

                Exit Sub
            End If

            Dim targetAsset As Asset = Nothing

            If setting = ORIGINAL_APPEARANCE Then

                Dim occ As ComponentOccurrence =
                    CType(row.Tag, ComponentOccurrence)

                targetAsset =
                    GetOriginalPartAppearanceForPreview(occ)

            ElseIf appearanceSources.ContainsKey(setting) Then

                targetAsset = appearanceSources(setting)

            End If

            '================================================
            ' V2.2
            ' まずInventorのRenderStyleから実サムネイル取得を試す。
            ' 成功すれば画像を表示。
            ' 失敗時だけ従来の代表色スウォッチへフォールバック。
            '================================================
            If targetAsset IsNot Nothing Then

                Dim thumb As System.Drawing.Bitmap =
                    GetInventorAppearanceThumbnail(targetAsset)

                If thumb IsNot Nothing Then

                    SetSwatchBitmap(
                        row,
                        CType(thumb.Clone(),
                              System.Drawing.Bitmap))

                    Exit Sub
                End If

            End If

            '----------------------------------------------
            ' フォールバック：従来の代表色
            '----------------------------------------------
            Dim swatchColor As System.Drawing.Color =
                GetAssetPreviewColor(targetAsset)

            SetSwatchBitmap(
                row,
                CreateColorSwatch(swatchColor))

        Catch

            SetSwatchBitmap(
                row,
                CreateColorSwatch(
                    System.Drawing.Color.LightGray))

        End Try

    End Sub


    '========================================================
    ' Inventor外観サムネイル取得（V2.2）
    '
    ' Asset自体にはサムネイルAPIが無いため、
    ' 旧RenderStyle.RealisticAppearanceThumbnailを
    ' Late Bindingで呼び出す。
    '
    ' ライブラリAssetが文書内に無い場合：
    '   1) Transaction開始
    '   2) 一時的にCopyTo
    '   3) RenderStyleから画像取得
    '   4) Bitmapへ変換
    '   5) TransactionをAbort
    '
    ' これによりテスト取得のためのAssetを文書へ残さない。
    '========================================================
    Private Function GetInventorAppearanceThumbnail(
        ByVal appearanceAsset As Asset) As System.Drawing.Bitmap

        If appearanceAsset Is Nothing Then Return Nothing

        Dim appearanceName As String = ""

        Try
            appearanceName = appearanceAsset.DisplayName
        Catch
            Return Nothing
        End Try

        If String.IsNullOrWhiteSpace(appearanceName) Then
            Return Nothing
        End If

        ' キャッシュ済み
        If _thumbnailCache.ContainsKey(appearanceName) Then
            Return _thumbnailCache(appearanceName)
        End If

        ' このセッションで取得失敗済み
        If _thumbnailFailed.Contains(appearanceName) Then
            Return Nothing
        End If

        Dim trans As Inventor.Transaction = Nothing
        Dim assetForRender As Asset = appearanceAsset
        Dim copiedTemporarily As Boolean = False

        Try

            ' 文書内に同名Assetがあるか確認
            Dim localAsset As Asset =
                FindAssemblyAppearanceAsset(
                    appearanceName)

            If localAsset IsNot Nothing Then

                assetForRender = localAsset

            Else

                ' ライブラリAsset等を一時コピー
                trans =
                    _app.TransactionManager.StartTransaction(
                        _asmDoc,
                        "外観サムネイル一時取得")

                assetForRender =
                    appearanceAsset.CopyTo(_asmDoc)

                copiedTemporarily = True

            End If

            Dim bmp As System.Drawing.Bitmap =
                TryGetRenderStyleThumbnail(
                    appearanceName)

            If bmp Is Nothing Then

                ' DisplayNameで見つからない場合、
                ' Asset.Nameでも試す。
                Try
                    bmp =
                        TryGetRenderStyleThumbnail(
                            assetForRender.Name)
                Catch
                End Try

            End If

            If bmp IsNot Nothing Then

                Dim normalized As System.Drawing.Bitmap =
                    NormalizeThumbnail(
                        bmp,
                        48,
                        32)

                bmp.Dispose()

                _thumbnailCache(appearanceName) =
                    normalized

                Return normalized

            End If

        Catch
            ' テスト版なので取得失敗時は代表色へフォールバック
        Finally

            If trans IsNot Nothing Then

                Try
                    ' 一時CopyToを含む変更をすべて破棄
                    trans.Abort()
                Catch
                End Try

                trans = Nothing

            End If

        End Try

        _thumbnailFailed.Add(appearanceName)

        Return Nothing

    End Function


    Private Function FindAssemblyAppearanceAsset(
        ByVal appearanceName As String) As Asset

        Try

            For Each a As Asset In _asmDoc.Assets

                If a.AssetType =
                   AssetTypeEnum.kAssetTypeAppearance AndAlso
                   String.Equals(
                       a.DisplayName,
                       appearanceName,
                       StringComparison.CurrentCultureIgnoreCase) Then

                    Return a

                End If

            Next

        Catch
        End Try

        Return Nothing

    End Function


    Private Function TryGetRenderStyleThumbnail(
        ByVal renderStyleName As String) As System.Drawing.Bitmap

        If String.IsNullOrWhiteSpace(renderStyleName) Then
            Return Nothing
        End If

        Try

            ' RenderStylesは旧APIで、現行APIでは非推奨。
            ' iLogicのコンパイル互換性を優先しLate Bindingで呼ぶ。
            Dim renderStylesObj As Object =
                Microsoft.VisualBasic.Interaction.CallByName(
                    _asmDoc,
                    "RenderStyles",
                    Microsoft.VisualBasic.CallType.Get)

            If renderStylesObj Is Nothing Then
                Return Nothing
            End If

            Dim renderStyleObj As Object = Nothing

            Try
                renderStyleObj =
                    Microsoft.VisualBasic.Interaction.CallByName(
                        renderStylesObj,
                        "Item",
                        Microsoft.VisualBasic.CallType.Get,
                        renderStyleName)
            Catch
                Return Nothing
            End Try

            If renderStyleObj Is Nothing Then
                Return Nothing
            End If

            Dim picObj As Object = Nothing

            ' Inventorバージョン差を考慮し、
            ' まず引数なしで呼ぶ。
            Try
                picObj =
                    Microsoft.VisualBasic.Interaction.CallByName(
                        renderStyleObj,
                        "RealisticAppearanceThumbnail",
                        Microsoft.VisualBasic.CallType.Method)
            Catch
            End Try

            ' 一部環境用の保険：プロパティとして取得を試す。
            If picObj Is Nothing Then
                Try
                    picObj =
                        Microsoft.VisualBasic.Interaction.CallByName(
                            renderStyleObj,
                            "RealisticAppearanceThumbnail",
                            Microsoft.VisualBasic.CallType.Get)
                Catch
                End Try
            End If

            If picObj Is Nothing Then Return Nothing

            Dim pic As stdole.IPictureDisp =
                TryCast(picObj, stdole.IPictureDisp)

            If pic Is Nothing Then Return Nothing

            Dim img As System.Drawing.Image =
                PictureConverter.ToImage(pic)

            If img Is Nothing Then Return Nothing

            ' COM画像から独立したBitmapへ複製
            Dim bmp As New System.Drawing.Bitmap(img)

            Try
                img.Dispose()
            Catch
            End Try

            Return bmp

        Catch
            Return Nothing
        End Try

    End Function


    Private Function NormalizeThumbnail(
        ByVal source As System.Drawing.Bitmap,
        ByVal width As Integer,
        ByVal height As Integer) As System.Drawing.Bitmap

        If source Is Nothing Then Return Nothing

        Dim result As New System.Drawing.Bitmap(
            width,
            height,
            System.Drawing.Imaging.PixelFormat.Format32bppArgb)

        Using g As System.Drawing.Graphics =
            System.Drawing.Graphics.FromImage(result)

            g.Clear(System.Drawing.Color.White)

            g.InterpolationMode =
                System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic

            g.PixelOffsetMode =
                System.Drawing.Drawing2D.PixelOffsetMode.HighQuality

            g.SmoothingMode =
                System.Drawing.Drawing2D.SmoothingMode.HighQuality

            Dim scaleX As Double =
                CDbl(width) / CDbl(source.Width)

            Dim scaleY As Double =
                CDbl(height) / CDbl(source.Height)

            Dim scale As Double =
                Math.Min(scaleX, scaleY)

            Dim drawW As Integer =
                Math.Max(
                    1,
                    CInt(source.Width * scale))

            Dim drawH As Integer =
                Math.Max(
                    1,
                    CInt(source.Height * scale))

            Dim x As Integer =
                (width - drawW) \ 2

            Dim y As Integer =
                (height - drawH) \ 2

            g.DrawImage(
                source,
                New System.Drawing.Rectangle(
                    x,
                    y,
                    drawW,
                    drawH))

            Using p As New System.Drawing.Pen(
                System.Drawing.Color.LightGray)

                g.DrawRectangle(
                    p,
                    0,
                    0,
                    width - 1,
                    height - 1)

            End Using

        End Using

        Return result

    End Function


    Private Function CreateColorSwatch(
        ByVal c As System.Drawing.Color) As System.Drawing.Bitmap

        Dim bmp As New System.Drawing.Bitmap(28, 18)

        Using g As System.Drawing.Graphics =
            System.Drawing.Graphics.FromImage(bmp)

            g.Clear(System.Drawing.Color.White)

            If c.A = 0 Then

                Using p As New System.Drawing.Pen(
                    System.Drawing.Color.Gray, 1)

                    g.DrawRectangle(p, 1, 1, 25, 15)
                    g.DrawLine(p, 2, 14, 25, 2)

                End Using

            Else

                Using br As New System.Drawing.SolidBrush(c)
                    g.FillRectangle(br, 2, 2, 24, 14)
                End Using

                Using p As New System.Drawing.Pen(
                    System.Drawing.Color.DimGray, 1)

                    g.DrawRectangle(p, 1, 1, 25, 15)

                End Using

            End If

        End Using

        Return bmp

    End Function


    Private Function GetAssetPreviewColor(
        ByVal appearanceAsset As Asset) As System.Drawing.Color

        If appearanceAsset Is Nothing Then
            Return System.Drawing.Color.LightGray
        End If

        '==================================================
        ' 1. 外観名そのものが明確な色名の場合
        '    Inventor内部Assetの構造差に左右されないよう、
        '    色名から代表RGBを確定する。
        '
        '    例：
        '      赤 / Red       -> 赤
        '      黄 / Yellow    -> 黄
        '      青 / Blue      -> 青
        '      緑 / Green     -> 緑
        '      白 / White     -> 白
        '      黒 / Black     -> 黒
        '      オレンジ       -> オレンジ
        '==================================================
        Try
            Dim namedColor As System.Drawing.Color
            Dim displayName As String = appearanceAsset.DisplayName

            If TryGetNamedAppearanceColor(
                displayName,
                namedColor) Then

                Return namedColor

            End If
        Catch
        End Try


        '==================================================
        ' 2. Generic外観の基本色
        '==================================================
        Try

            Dim diffuseValue As AssetValue =
                appearanceAsset.Item("generic_diffuse")

            If diffuseValue IsNot Nothing AndAlso
               diffuseValue.Type =
               ObjectTypeEnum.kColorAssetValueObject Then

                Dim diffuseColorValue As ColorAssetValue =
                    CType(diffuseValue, ColorAssetValue)

                Dim invColor As Inventor.Color =
                    diffuseColorValue.Value

                If invColor IsNot Nothing Then

                    Return InventorColorToDrawingColor(
                        invColor)

                End If

            End If

        Catch
        End Try


        '==================================================
        ' 3. 外観Asset内のColorAssetValueをすべて確認し、
        '    「代表色らしい項目」をスコアリングして選択する。
        '
        '    diffuse / albedo / base / color を優先し、
        '    reflect / specular / highlight / emission /
        '    bump / transparency などは代表色候補から下げる。
        '==================================================
        Try

            Dim bestColor As Inventor.Color = Nothing
            Dim bestScore As Integer = Integer.MinValue

            For i As Integer = 1 To appearanceAsset.Count

                Try

                    Dim av As AssetValue =
                        appearanceAsset.Item(i)

                    If av.Type <>
                       ObjectTypeEnum.kColorAssetValueObject Then

                        Continue For

                    End If

                    Dim cav As ColorAssetValue =
                        CType(av, ColorAssetValue)

                    Dim invColor As Inventor.Color =
                        cav.Value

                    If invColor Is Nothing Then Continue For

                    Dim valueName As String = ""

                    Try
                        valueName = av.Name
                    Catch
                    End Try

                    Dim score As Integer =
                        GetColorAssetValueScore(valueName)

                    If score > bestScore Then

                        bestScore = score
                        bestColor = invColor

                    End If

                Catch
                End Try

            Next

            If bestColor IsNot Nothing AndAlso
               bestScore > -500 Then

                Return InventorColorToDrawingColor(
                    bestColor)

            End If

        Catch
        End Try


        '==================================================
        ' 4. 色を確定できない外観
        '    誤った色を表示するよりニュートラルグレーとする。
        '==================================================
        Return System.Drawing.Color.LightGray

    End Function


    Private Function InventorColorToDrawingColor(
        ByVal invColor As Inventor.Color) As System.Drawing.Color

        If invColor Is Nothing Then
            Return System.Drawing.Color.LightGray
        End If

        Dim r As Integer =
            Math.Max(0, Math.Min(255, CInt(invColor.Red)))

        Dim g As Integer =
            Math.Max(0, Math.Min(255, CInt(invColor.Green)))

        Dim b As Integer =
            Math.Max(0, Math.Min(255, CInt(invColor.Blue)))

        Return System.Drawing.Color.FromArgb(r, g, b)

    End Function


    Private Function GetColorAssetValueScore(
        ByVal valueName As String) As Integer

        Dim nm As String =
            If(valueName, "").ToLowerInvariant()

        Dim score As Integer = 0

        '----------------------------------------------
        ' 代表色として強く優先
        '----------------------------------------------
        If nm.Contains("diffuse") Then score += 1000
        If nm.Contains("albedo") Then score += 950
        If nm.Contains("base") Then score += 850
        If nm.Contains("main") Then score += 750
        If nm.Contains("surface") Then score += 650
        If nm.Contains("color") Then score += 550
        If nm.Contains("colour") Then score += 550
        If nm.Contains("tint") Then score += 150

        '----------------------------------------------
        ' 代表色として使わない／優先度を大きく下げる
        '----------------------------------------------
        If nm.Contains("reflect") Then score -= 1200
        If nm.Contains("specular") Then score -= 1200
        If nm.Contains("highlight") Then score -= 1200
        If nm.Contains("self_illum") Then score -= 1500
        If nm.Contains("emission") Then score -= 1500
        If nm.Contains("bump") Then score -= 1500
        If nm.Contains("cutout") Then score -= 1500
        If nm.Contains("transparency") Then score -= 1300
        If nm.Contains("transmitt") Then score -= 1000
        If nm.Contains("refraction") Then score -= 1000

        Return score

    End Function


    Private Function TryGetNamedAppearanceColor(
        ByVal appearanceName As String,
        ByRef resultColor As System.Drawing.Color) As Boolean

        If String.IsNullOrWhiteSpace(appearanceName) Then
            Return False
        End If

        Dim nm As String =
            appearanceName.Trim().ToLowerInvariant()

        '==================================================
        ' 日本語の明確な基本色
        ' 完全一致を最優先
        '==================================================
        Select Case nm

            Case "赤"
                resultColor = System.Drawing.Color.FromArgb(255, 0, 0)
                Return True

            Case "黄", "黄色"
                resultColor = System.Drawing.Color.FromArgb(255, 255, 0)
                Return True

            Case "緑"
                resultColor = System.Drawing.Color.FromArgb(0, 255, 0)
                Return True

            Case "青"
                resultColor = System.Drawing.Color.FromArgb(0, 0, 255)
                Return True

            Case "シアン", "水色"
                resultColor = System.Drawing.Color.FromArgb(0, 255, 255)
                Return True

            Case "マゼンタ"
                resultColor = System.Drawing.Color.FromArgb(255, 0, 255)
                Return True

            Case "白"
                resultColor = System.Drawing.Color.FromArgb(255, 255, 255)
                Return True

            Case "黒"
                resultColor = System.Drawing.Color.FromArgb(0, 0, 0)
                Return True

            Case "オレンジ", "橙", "橙色"
                resultColor = System.Drawing.Color.FromArgb(255, 165, 0)
                Return True

            Case "紫", "紫色"
                resultColor = System.Drawing.Color.FromArgb(128, 0, 128)
                Return True

            Case "茶", "茶色"
                resultColor = System.Drawing.Color.FromArgb(165, 42, 42)
                Return True

            Case "灰色", "グレー", "グレイ"
                resultColor = System.Drawing.Color.FromArgb(128, 128, 128)
                Return True

            Case "ピンク", "桃色"
                resultColor = System.Drawing.Color.FromArgb(255, 192, 203)
                Return True

        End Select


        '==================================================
        ' 英語の明確な基本色
        '==================================================
        Select Case nm

            Case "red"
                resultColor = System.Drawing.Color.FromArgb(255, 0, 0)
                Return True

            Case "yellow"
                resultColor = System.Drawing.Color.FromArgb(255, 255, 0)
                Return True

            Case "green"
                resultColor = System.Drawing.Color.FromArgb(0, 255, 0)
                Return True

            Case "blue"
                resultColor = System.Drawing.Color.FromArgb(0, 0, 255)
                Return True

            Case "cyan"
                resultColor = System.Drawing.Color.FromArgb(0, 255, 255)
                Return True

            Case "magenta"
                resultColor = System.Drawing.Color.FromArgb(255, 0, 255)
                Return True

            Case "white"
                resultColor = System.Drawing.Color.FromArgb(255, 255, 255)
                Return True

            Case "black"
                resultColor = System.Drawing.Color.FromArgb(0, 0, 0)
                Return True

            Case "orange"
                resultColor = System.Drawing.Color.FromArgb(255, 165, 0)
                Return True

            Case "purple", "violet"
                resultColor = System.Drawing.Color.FromArgb(128, 0, 128)
                Return True

            Case "brown"
                resultColor = System.Drawing.Color.FromArgb(165, 42, 42)
                Return True

            Case "gray", "grey"
                resultColor = System.Drawing.Color.FromArgb(128, 128, 128)
                Return True

            Case "pink"
                resultColor = System.Drawing.Color.FromArgb(255, 192, 203)
                Return True

        End Select


        '==================================================
        ' 複合色名
        ' 完全一致ではないが、色名が明確な場合だけ補助判定。
        ' 材質名の一部に偶然色文字が含まれるケースを避けるため、
        ' 強い色語だけを扱う。
        '==================================================

        If nm.Contains("明るい青紫") Then

            resultColor =
                System.Drawing.Color.FromArgb(138, 130, 238)

            Return True

        End If

        If nm.Contains("青紫") Then

            resultColor =
                System.Drawing.Color.FromArgb(106, 90, 205)

            Return True

        End If

        If nm.Contains("明るい青") Then

            resultColor =
                System.Drawing.Color.FromArgb(135, 206, 250)

            Return True

        End If

        If nm.Contains("濃い青") Then

            resultColor =
                System.Drawing.Color.FromArgb(0, 0, 139)

            Return True

        End If

        If nm.Contains("明るい緑") Then

            resultColor =
                System.Drawing.Color.FromArgb(144, 238, 144)

            Return True

        End If

        If nm.Contains("濃い緑") Then

            resultColor =
                System.Drawing.Color.FromArgb(0, 100, 0)

            Return True

        End If

        If nm.Contains("明るい赤") Then

            resultColor =
                System.Drawing.Color.FromArgb(255, 99, 71)

            Return True

        End If

        If nm.Contains("濃い赤") Then

            resultColor =
                System.Drawing.Color.FromArgb(139, 0, 0)

            Return True

        End If

        Return False

    End Function


    Private Function CanFavoriteAppearance(
        ByVal appearanceName As String) As Boolean

        If String.IsNullOrWhiteSpace(appearanceName) Then
            Return False
        End If

        If appearanceName = NO_CHANGE OrElse
           appearanceName = ORIGINAL_APPEARANCE Then
            Return False
        End If

        Return appearanceNames.Contains(appearanceName)

    End Function


    Private Function IsFavoriteAppearance(
        ByVal appearanceName As String) As Boolean

        If Not CanFavoriteAppearance(appearanceName) Then
            Return False
        End If

        Return favoriteAppearanceNames.Contains(
            appearanceName)

    End Function


    Private Sub RefreshFavoriteChecks()

        _isRebuilding = True

        Try

            For Each row As DataGridViewRow In grid.Rows

                Dim selectedAppearance As String =
                    Convert.ToString(
                        row.Cells("NewAppearance").Value)

                row.Cells("Favorite").Value =
                    IsFavoriteAppearance(selectedAppearance)

            Next

        Finally
            _isRebuilding = False
        End Try

    End Sub


    '========================================================
    ' お気に入り保存
    '========================================================
    Private Function GetFavoritesFilePath() As String

        Try
            Dim baseDir As String =
                System.IO.Path.Combine(
                    System.Environment.GetFolderPath(
                        System.Environment.SpecialFolder.ApplicationData),
                    "InventorAssemblyAppearanceManager")

            If Not System.IO.Directory.Exists(baseDir) Then
                System.IO.Directory.CreateDirectory(baseDir)
            End If

            ' 外観お気に入りは全アセンブリ共通
            Return System.IO.Path.Combine(
                baseDir,
                "FavoriteAppearances.txt")

        Catch
            Return ""
        End Try

    End Function


    Private Sub LoadFavorites()

        favoriteAppearanceNames.Clear()

        If String.IsNullOrWhiteSpace(_favoritesFile) Then Exit Sub

        Try

            If Not System.IO.File.Exists(_favoritesFile) Then
                Exit Sub
            End If

            For Each line As String In
                System.IO.File.ReadAllLines(
                    _favoritesFile,
                    System.Text.Encoding.UTF8)

                Dim nm As String = line.Trim()

                If nm <> "" Then
                    favoriteAppearanceNames.Add(nm)
                End If

            Next

        Catch
        End Try

    End Sub


    Private Sub SaveFavorites()

        If String.IsNullOrWhiteSpace(_favoritesFile) Then Exit Sub

        Try

            Dim values As New List(Of String)

            For Each nm As String In favoriteAppearanceNames
                values.Add(nm)
            Next

            values.Sort(
                StringComparer.CurrentCultureIgnoreCase)

            System.IO.File.WriteAllLines(
                _favoritesFile,
                values.ToArray(),
                System.Text.Encoding.UTF8)

        Catch ex As Exception

            System.Windows.Forms.MessageBox.Show(
                "外観のお気に入り情報を保存できませんでした。" &
                vbCrLf & ex.Message,
                "お気に入り",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning)

        End Try

    End Sub


    '========================================================
    ' 検索
    '========================================================
    Private Sub SearchChanged(
        ByVal sender As Object,
        ByVal e As EventArgs)

        If _isRebuilding Then Exit Sub

        ApplyAppearanceSearchToSelectedRow()

    End Sub


    '========================================================
    ' 選択行の「設定する外観」だけを検索する
    '========================================================
    Private Sub ApplyAppearanceSearchToSelectedRow()

        If grid.CurrentRow Is Nothing Then Exit Sub

        Dim row As DataGridViewRow = grid.CurrentRow

        Try

            Dim cell As DataGridViewComboBoxCell =
                TryCast(
                    row.Cells("NewAppearance"),
                    DataGridViewComboBoxCell)

            If cell Is Nothing Then Exit Sub

            Dim currentValue As String =
                Convert.ToString(cell.Value)

            _isRebuilding = True

            PopulateAppearanceCell(
                cell,
                currentValue,
                txtSearch.Text)

        Catch ex As Exception

            System.Windows.Forms.MessageBox.Show(
                "外観検索中にエラーが発生しました。" &
                vbCrLf & ex.Message,
                "外観検索",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning)

        Finally
            _isRebuilding = False
        End Try

    End Sub


    Private Sub ShowOperationResult(
        ByVal titleText As String,
        ByVal successCount As Integer,
        ByVal skipCount As Integer,
        ByVal errorCount As Integer,
        ByVal errorDetails As List(Of String))

        Dim msg As String =
            titleText &
            vbCrLf & vbCrLf &
            "変更：" & successCount & " 個"

        If skipCount > 0 Then
            msg &= vbCrLf &
                "変更なし：" & skipCount & " 個"
        End If

        msg &= vbCrLf &
            "エラー：" & errorCount & " 個"

        If errorCount > 0 AndAlso
           errorDetails IsNot Nothing AndAlso
           errorDetails.Count > 0 Then

            msg &= vbCrLf & vbCrLf &
                "【エラー詳細】"

            Dim maxLines As Integer =
                Math.Min(15, errorDetails.Count)

            For i As Integer = 0 To maxLines - 1
                msg &= vbCrLf &
                    "・" & errorDetails(i)
            Next

            If errorDetails.Count > maxLines Then
                msg &= vbCrLf &
                    "・ほか " &
                    (errorDetails.Count - maxLines) &
                    " 件"
            End If

        End If

        System.Windows.Forms.MessageBox.Show(
            msg,
            "部品外観変更",
            MessageBoxButtons.OK,
            If(errorCount = 0,
               MessageBoxIcon.Information,
               MessageBoxIcon.Warning))

    End Sub


    '========================================================
    ' 一括適用
    ' 各行に設定された外観を個別に適用する
    '========================================================
    Private Sub ApplyClicked(
        ByVal sender As Object,
        ByVal e As EventArgs)

        grid.EndEdit()

        Dim successCount As Integer = 0
        Dim skipCount As Integer = 0
        Dim errorCount As Integer = 0
        Dim errorDetails As New List(Of String)

        Dim trans As Inventor.Transaction = Nothing

        Try

            trans =
                _app.TransactionManager.StartTransaction(
                    _asmDoc,
                    "アセンブリ部品外観変更")

            For Each row As DataGridViewRow In grid.Rows

                Dim setting As String =
                    Convert.ToString(
                        row.Cells("NewAppearance").Value)

                If String.IsNullOrWhiteSpace(setting) OrElse
                   setting = NO_CHANGE Then

                    skipCount += 1
                    Continue For
                End If

                Dim occ As ComponentOccurrence =
                    TryCast(row.Tag, ComponentOccurrence)

                If occ Is Nothing Then
                    errorCount += 1
                    errorDetails.Add(
                        "(Occurrence取得不可) : " & setting)
                    Continue For
                End If

                Try

                    Dim targetAsset As Asset = Nothing

                    If setting = ORIGINAL_APPEARANCE Then

                        ' 厳密なOverride削除ではなく、
                        ' パーツ本来のActiveAppearanceを
                        ' Occurrenceへ再適用する仕様。
                        targetAsset =
                            GetOriginalPartAppearance(occ)

                    Else

                        targetAsset =
                            GetAssemblyAppearanceAsset(setting)

                    End If

                    If targetAsset Is Nothing Then

                        errorCount += 1

                        errorDetails.Add(
                            occ.Name &
                            " : 外観「" & setting &
                            "」を取得できません。")

                        Continue For
                    End If

                    ' .ipt は変更せずOccurrenceだけ変更
                    occ.Appearance = targetAsset

                    row.Cells("CurrentAppearance").Value =
                        targetAsset.DisplayName

                    row.Cells("NewAppearance").Value =
                        NO_CHANGE

                    pendingSettings(
                        OccurrenceKey(occ)) = NO_CHANGE

                    UpdateSwatchForRow(row)

                    successCount += 1

                Catch ex As Exception

                    errorCount += 1

                    errorDetails.Add(
                        occ.Name &
                        " : " & ex.Message)

                End Try

            Next

            Try
                _asmDoc.Update()
            Catch ex As Exception
                errorDetails.Add(
                    "ドキュメント更新 : " & ex.Message)
                errorCount += 1
            End Try

            If trans IsNot Nothing Then
                trans.End()
                trans = Nothing
            End If

        Catch ex As Exception

            If trans IsNot Nothing Then
                Try
                    trans.Abort()
                Catch
                End Try
                trans = Nothing
            End If

            System.Windows.Forms.MessageBox.Show(
                "外観変更処理を完了できませんでした。" &
                vbCrLf & vbCrLf &
                ex.Message,
                "部品外観変更",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)

            Exit Sub

        End Try

        ShowOperationResult(
            "外観設定を実行しました。",
            successCount,
            skipCount,
            errorCount,
            errorDetails)

    End Sub


    '========================================================
    ' 選択した行だけ元の外観へ戻す
    '========================================================
    Private Sub ResetSelectedClicked(
        ByVal sender As Object,
        ByVal e As EventArgs)

        If grid.SelectedRows.Count = 0 Then

            System.Windows.Forms.MessageBox.Show(
                "元の外観へ戻す行を選択してください。",
                "部品外観変更",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information)

            Exit Sub
        End If

        Dim successCount As Integer = 0
        Dim errorCount As Integer = 0
        Dim errorDetails As New List(Of String)

        Dim trans As Inventor.Transaction = Nothing

        Try

            trans =
                _app.TransactionManager.StartTransaction(
                    _asmDoc,
                    "選択部品を元の外観に戻す")

            For Each row As DataGridViewRow In grid.SelectedRows

                Dim occ As ComponentOccurrence =
                    TryCast(row.Tag, ComponentOccurrence)

                If occ Is Nothing Then
                    errorCount += 1
                    errorDetails.Add(
                        "(Occurrence取得不可)")
                    Continue For
                End If

                Try

                    Dim originalAsset As Asset =
                        GetOriginalPartAppearance(occ)

                    If originalAsset Is Nothing Then

                        errorCount += 1

                        errorDetails.Add(
                            occ.Name &
                            " : 元の外観を取得できません。")

                        Continue For
                    End If

                    ' 現仕様はOverrideの完全削除ではなく、
                    ' PartのActiveAppearanceを再適用する。
                    occ.Appearance = originalAsset

                    row.Cells("CurrentAppearance").Value =
                        originalAsset.DisplayName

                    row.Cells("NewAppearance").Value =
                        NO_CHANGE

                    pendingSettings(
                        OccurrenceKey(occ)) = NO_CHANGE

                    UpdateSwatchForRow(row)

                    successCount += 1

                Catch ex As Exception

                    errorCount += 1

                    errorDetails.Add(
                        occ.Name &
                        " : " & ex.Message)

                End Try

            Next

            Try
                _asmDoc.Update()
            Catch ex As Exception
                errorDetails.Add(
                    "ドキュメント更新 : " & ex.Message)
                errorCount += 1
            End Try

            If trans IsNot Nothing Then
                trans.End()
                trans = Nothing
            End If

        Catch ex As Exception

            If trans IsNot Nothing Then
                Try
                    trans.Abort()
                Catch
                End Try
                trans = Nothing
            End If

            System.Windows.Forms.MessageBox.Show(
                "元の外観へ戻す処理を完了できませんでした。" &
                vbCrLf & vbCrLf &
                ex.Message,
                "部品外観変更",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)

            Exit Sub

        End Try

        ShowOperationResult(
            "選択行を元の外観に戻しました。",
            successCount,
            0,
            errorCount,
            errorDetails)

    End Sub


    '========================================================
    ' 選択行で指定している外観のお気に入りを個別解除
    ' 外観設定そのものは変更しない
    '========================================================
    Private Sub RemoveFavoriteClicked(
        ByVal sender As Object,
        ByVal e As EventArgs)

        If grid.CurrentRow Is Nothing Then

            System.Windows.Forms.MessageBox.Show(
                "お気に入りを解除する行を選択してください。",
                "お気に入り解除",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information)

            Exit Sub
        End If

        Dim row As DataGridViewRow = grid.CurrentRow

        Dim selectedAppearance As String =
            Convert.ToString(
                row.Cells("NewAppearance").Value)

        If Not CanFavoriteAppearance(selectedAppearance) Then

            System.Windows.Forms.MessageBox.Show(
                "この行ではお気に入り対象の外観が選択されていません。" &
                vbCrLf &
                "「設定する外観」から解除したい外観を選択してください。",
                "お気に入り解除",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information)

            Exit Sub
        End If

        If Not favoriteAppearanceNames.Contains(
            selectedAppearance) Then

            System.Windows.Forms.MessageBox.Show(
                "「" & selectedAppearance &
                "」はお気に入りに登録されていません。",
                "お気に入り解除",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information)

            Exit Sub
        End If

        favoriteAppearanceNames.Remove(
            selectedAppearance)

        SaveFavorites()

        ' 現在値を保持したままプルダウンの並びと表示を更新
        SavePendingSettingsFromGrid()
        RefreshAppearanceComboAfterFavoriteChange()
        RefreshFavoriteChecks()

        lblCount.Text =
            "表示：" & grid.Rows.Count &
            " / 全部品：" & allOccurrences.Count &
            " / お気に入り外観：" &
            favoriteAppearanceNames.Count

        System.Windows.Forms.MessageBox.Show(
            "「" & selectedAppearance &
            "」のお気に入りを解除しました。" &
            vbCrLf &
            "部品の外観設定は変更していません。",
            "お気に入り解除",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information)

    End Sub


    Private Sub ClearSettingsClicked(
        ByVal sender As Object,
        ByVal e As EventArgs)

        For Each row As DataGridViewRow In grid.Rows

            row.Cells("NewAppearance").Value = NO_CHANGE

            Try
                Dim occ As ComponentOccurrence =
                    CType(row.Tag, ComponentOccurrence)

                If occ IsNot Nothing Then
                    pendingSettings(OccurrenceKey(occ)) =
                        NO_CHANGE
                End If
            Catch
            End Try

            UpdateSwatchForRow(row)

        Next

    End Sub


    Private Sub AppearanceManagerFormClosed(
        ByVal sender As Object,
        ByVal e As FormClosedEventArgs)

        CleanupResources()

    End Sub


    Private Sub CleanupResources()

        Try
            DisposeAllSwatchBitmaps()
        Catch
        End Try

        Try
            For Each bmp As System.Drawing.Bitmap In
                _thumbnailCache.Values

                If bmp IsNot Nothing Then
                    bmp.Dispose()
                End If

            Next

            _thumbnailCache.Clear()
            _thumbnailFailed.Clear()
        Catch
        End Try

        Try
            If _favoriteFont IsNot Nothing Then
                _favoriteFont.Dispose()
                _favoriteFont = Nothing
            End If
        Catch
        End Try

    End Sub


    Private Sub CloseClicked(
        ByVal sender As Object,
        ByVal e As EventArgs)

        Me.Close()

    End Sub

End Class
