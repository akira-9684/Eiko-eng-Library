'============================================================
' iLogic Level Checker v1.6
' Autodesk Inventor Assembly (.iam)
'
' Purpose:
'   1) Select a planar reference as FL +/- 0
'   2) Select one point on the FL+ side to define positive direction
'   3) Write "基準面 FL±0" only after FL+ direction is confirmed
'   4) Select FL-parallel planar faces continuously
'   5) Calculate signed level from actual clicked model positions
'   6) Create persistent sketch text on the selected face
'   7) ESC finishes measurement
'
' Notes:
'   - Inventor internal database length unit is cm.
'   - Displayed values are converted to mm.
'   - After selecting FL +/- 0, click any planar face on the FL+ side.
'   - The selected point defines the positive direction, independent
'     of the assembly X/Y/Z orientation or face-normal direction.
'============================================================

Sub Main()

    Const RULE_TITLE As String = "iLogic Level Checker v1.6"
    Const SKETCH_PREFIX As String = "LEVEL_"
    Const ASK_COMMENT As Boolean = True
    Const ROUND_DIGITS As Integer = 0      '0 = 1 mm, 1 = 0.1 mm
    Const PARALLEL_TOLERANCE As Double = 0.01  'sin(angle), approx 0.57 deg
    Const DEFAULT_TEXT_HEIGHT_MM As Double = 10.0
    Const TEXT_HEIGHT_PROPERTY As String = "LevelChecker_TextHeightMM"  'Sketch text height

    Dim oApp As Inventor.Application = ThisApplication
    Dim oDoc As Inventor.Document = oApp.ActiveDocument

    If oDoc Is Nothing OrElse oDoc.DocumentType <> Inventor.DocumentTypeEnum.kAssemblyDocumentObject Then
        MessageBox.Show("アセンブリ(.iam)を開いて実行してください。", RULE_TITLE)
        Exit Sub
    End If

    Dim oAsmDoc As Inventor.AssemblyDocument = CType(oDoc, Inventor.AssemblyDocument)
    Dim oAsmDef As Inventor.AssemblyComponentDefinition = oAsmDoc.ComponentDefinition

    ' Load the last-used text height stored in the assembly.
    Dim currentTextHeightMM As Double =
        GetStoredTextHeightMM(oAsmDoc, TEXT_HEIGHT_PROPERTY, DEFAULT_TEXT_HEIGHT_MM)

    '--------------------------------------------------------
    ' 1. Select reference plane (FL +/- 0)
    '--------------------------------------------------------
    Dim refObj As Object = Nothing
    Dim refClickPoint As Inventor.Point = Nothing

    ' Select the FL±0 reference and remember the exact click position.
    Dim refPicker As New PlanarFacePointPicker(oApp)
    refObj = refPicker.Pick(
        Inventor.SelectionFilterEnum.kAllPlanarEntities,
        "FL±0 の基準となる平面または平面フェースをクリックしてください。ESC=終了",
        refClickPoint)

    If refObj Is Nothing Then Exit Sub

    Dim refPlane As Inventor.Plane = GetPlane(refObj)
    If refPlane Is Nothing Then
        MessageBox.Show("基準面を取得できませんでした。平面フェースまたは作業平面を選択してください。", RULE_TITLE)
        Exit Sub
    End If

    '--------------------------------------------------------
    ' Reference normal and FL+ direction.
    '
    ' A planar face normal can point either way, and the assembly
    ' itself may use X, Y or Z as the real-world vertical axis.
    ' Therefore do not assume global +Z.  Ask the user to click
    ' once on the FL+ side and orient the reference normal toward
    ' that clicked 3D point.
    '--------------------------------------------------------
    Dim nx As Double = refPlane.Normal.X
    Dim ny As Double = refPlane.Normal.Y
    Dim nz As Double = refPlane.Normal.Z
    ' Use the actual clicked point as the FL reference point whenever possible.
    ' This keeps the distance calculation in the same assembly/model coordinate
    ' system as InteractionEvents.ModelPosition.
    Dim refPt As Inventor.Point = Nothing
    If refClickPoint IsNot Nothing Then
        refPt = refClickPoint.Copy()
    Else
        refPt = refPlane.RootPoint
    End If


    Dim plusPoint As Inventor.Point = Nothing
    Dim plusObj As Object = Nothing

    Do
        Dim plusPicker As New PlanarFacePointPicker(oApp)
        plusObj = plusPicker.Pick(
            Inventor.SelectionFilterEnum.kPartFacePlanarFilter,
            "FL＋側にある任意の平面フェースを1回クリックしてください。クリック位置で＋方向を決定します。ESC=終了",
            plusPoint)

        If plusObj Is Nothing OrElse plusPoint Is Nothing Then Exit Sub

        Dim pdx As Double = plusPoint.X - refPt.X
        Dim pdy As Double = plusPoint.Y - refPt.Y
        Dim pdz As Double = plusPoint.Z - refPt.Z
        Dim plusSide As Double = pdx * nx + pdy * ny + pdz * nz

        ' If the clicked point is essentially on FL±0, it cannot
        ' tell us which side is positive. Ask again.
        If Math.Abs(plusSide) < 0.001 Then
            MessageBox.Show(
                "選択した位置がFL±0とほぼ同じレベルです。" & vbCrLf &
                "FL＋側（FLより上側）にある面を選択してください。",
                RULE_TITLE)
            plusPoint = Nothing
            Continue Do
        End If

        If plusSide < 0.0 Then
            nx = -nx
            ny = -ny
            nz = -nz
        End If

        Exit Do
    Loop

    '--------------------------------------------------------
    ' FL±0 and FL+ direction are now both confirmed.
    ' Only now create the persistent reference label, so ESC during
    ' FL+ selection does not leave an orphan reference sketch.
    '--------------------------------------------------------
    Try
        Dim refSketch As Inventor.PlanarSketch = oAsmDef.Sketches.Add(refObj, False)
        refSketch.Name = GetUniqueSketchName(oAsmDef, "LEVEL_REFERENCE_FL0")

        Dim refPos2d As Inventor.Point2d
        If refClickPoint IsNot Nothing Then
            refPos2d = refSketch.ModelToSketchSpace(refClickPoint)
        Else
            refPos2d = refSketch.ModelToSketchSpace(refPt)
        End If

        Dim refTextHeightCm As Double = currentTextHeightMM / 10.0
        Dim refLabel As String = "基準面 FL±0"
        Dim refFormatted As String =
            "<StyleOverride FontSize='" &
            refTextHeightCm.ToString(System.Globalization.CultureInfo.InvariantCulture) &
            "'>" & EscapeXml(refLabel) & "</StyleOverride>"

        refSketch.TextBoxes.AddFitted(refPos2d, refFormatted)
        refSketch.Visible = True
        oApp.ActiveView.Update()

    Catch ex As Exception
        MessageBox.Show(
            "FL±0 と FL＋方向は設定できましたが、「基準面 FL±0」の文字配置に失敗しました。" &
            vbCrLf & vbCrLf & ex.Message,
            RULE_TITLE)
    End Try

    MessageBox.Show(
        "FL±0 と FL＋方向を設定しました。" & vbCrLf & vbCrLf &
        "続けてレベルを調べたい平面フェースをクリックしてください。" & vbCrLf &
        "クリック位置に文字を配置します。ESCで終了します。",
        RULE_TITLE)

    '--------------------------------------------------------
    ' 2. Continuous measurement
    '--------------------------------------------------------
    Dim index As Integer = 1

    Do
        Dim targetObj As Object = Nothing
        Dim clickPoint3d As Inventor.Point = Nothing

        ' Get both the selected planar face and the exact graphics-window
        ' click position projected onto that face.
        Dim picker As New PlanarFacePointPicker(oApp)
        targetObj = picker.Pick(
            Inventor.SelectionFilterEnum.kPartFacePlanarFilter,
            "レベルを測定する平面フェースをクリックしてください。クリック位置に文字を配置します。ESC=終了",
            clickPoint3d)

        If targetObj Is Nothing Then Exit Do

        Dim targetPlane As Inventor.Plane = GetPlane(targetObj)
        If targetPlane Is Nothing Then
            MessageBox.Show("選択したフェースの平面を取得できませんでした。", RULE_TITLE)
            Continue Do
        End If

        '----------------------------------------------------
        ' Safety check: the measured face must be parallel to FL.
        ' For unit normal vectors, the magnitude of the cross product
        ' equals sin(theta). 0.01 is approximately 0.57 degrees.
        '----------------------------------------------------
        Dim tnx As Double = targetPlane.Normal.X
        Dim tny As Double = targetPlane.Normal.Y
        Dim tnz As Double = targetPlane.Normal.Z

        Dim cx As Double = ny * tnz - nz * tny
        Dim cy As Double = nz * tnx - nx * tnz
        Dim cz As Double = nx * tny - ny * tnx
        Dim crossMag As Double = Math.Sqrt(cx * cx + cy * cy + cz * cz)

        If crossMag > PARALLEL_TOLERANCE Then
            MessageBox.Show(
                "選択面がFL基準面と平行ではありません。" & vbCrLf &
                "水平（FLと平行）な面を選択してください。",
                RULE_TITLE)
            Continue Do
        End If

        '----------------------------------------------------
        ' Signed distance from FL plane along reference normal.
        ' Use the actual clicked ModelPosition instead of Plane.RootPoint.
        ' This improves robustness for translated/rotated occurrences.
        ' Inventor database length unit = cm.
        '----------------------------------------------------
        Dim p As Inventor.Point = clickPoint3d
        If p Is Nothing Then
            p = targetPlane.RootPoint
        End If

        Dim dx As Double = p.X - refPt.X
        Dim dy As Double = p.Y - refPt.Y
        Dim dz As Double = p.Z - refPt.Z

        Dim levelCm As Double = dx * nx + dy * ny + dz * nz
        Dim levelMm As Double = levelCm * 10.0
        levelMm = Math.Round(levelMm, ROUND_DIGITS, MidpointRounding.AwayFromZero)

        Dim levelText As String = FormatLevel(levelMm, ROUND_DIGITS)

        ' Comment + text height
        Dim commentText As String = ""
        Dim selectedTextHeightMM As Double = currentTextHeightMM

        If ASK_COMMENT Then
            Dim inputResult As Boolean =
                ShowLevelTextDialog(commentText, selectedTextHeightMM, RULE_TITLE)

            If Not inputResult Then
                Continue Do
            End If

            currentTextHeightMM = selectedTextHeightMM
            SaveStoredTextHeightMM(oAsmDoc, TEXT_HEIGHT_PROPERTY, currentTextHeightMM)
        End If

        Dim fullText As String
        If String.IsNullOrWhiteSpace(commentText) Then
            fullText = levelText
        Else
            fullText = commentText.Trim() & vbCrLf & levelText
        End If

        '----------------------------------------------------
        ' 3. Create persistent assembly sketch text
        '----------------------------------------------------
        Try
            Dim oSketch As Inventor.PlanarSketch = oAsmDef.Sketches.Add(targetObj, False)

            Dim safeComment As String = MakeSafeName(commentText)
            If safeComment = "" Then safeComment = "LEVEL"

            Dim proposedName As String = SKETCH_PREFIX & index.ToString("000") & "_" & safeComment
            oSketch.Name = GetUniqueSketchName(oAsmDef, proposedName)

            ' Place the text at the exact position where the user clicked
            ' the selected face in the graphics window.
            Dim pos2d As Inventor.Point2d

            If clickPoint3d IsNot Nothing Then
                pos2d = oSketch.ModelToSketchSpace(clickPoint3d)
            Else
                ' Safety fallback only. Normally clickPoint3d is always available
                ' because the face is selected through InteractionEvents.
                Dim center3d As Inventor.Point = GetFaceCenterPoint(targetObj, oApp)
                If center3d IsNot Nothing Then
                    pos2d = oSketch.ModelToSketchSpace(center3d)
                Else
                    pos2d = oApp.TransientGeometry.CreatePoint2d(0, 0)
                End If
            End If

            ' Formatted text; text height in cm because model database units are cm.
            Dim textHeightCm As Double = currentTextHeightMM / 10.0
            Dim formatted As String =
                "<StyleOverride FontSize='" & textHeightCm.ToString(System.Globalization.CultureInfo.InvariantCulture) & "'>" &
                EscapeXml(fullText).Replace(vbCrLf, "<Br/>") &
                "</StyleOverride>"

            Dim oText As Inventor.TextBox = oSketch.TextBoxes.AddFitted(pos2d, formatted)

            ' Keep sketch visible.
            oSketch.Visible = True

            index += 1
            oApp.ActiveView.Update()

        Catch ex As Exception
            MessageBox.Show(
                "レベルは取得できましたが、文字の配置に失敗しました。" & vbCrLf & vbCrLf &
                levelText & vbCrLf & vbCrLf &
                "エラー: " & ex.Message,
                RULE_TITLE)
            Continue Do
        End Try

    Loop

    MessageBox.Show(
        "レベル測定を終了しました。" & vbCrLf &
        "配置したレベル文字はアセンブリスケッチとして残ります。",
        RULE_TITLE)

End Sub





'============================================================
' Persistent text-height setting
'============================================================
Function GetStoredTextHeightMM(doc As Inventor.Document,
                               propertyName As String,
                               defaultValue As Double) As Double
    Try
        Dim ps As Inventor.PropertySet =
            doc.PropertySets.Item("Inventor User Defined Properties")
        Dim p As Inventor.Property = ps.Item(propertyName)

        Try
            Dim v As Double = CDbl(p.Value)
            If v > 0 Then Return v
        Catch
        End Try
    Catch
    End Try

    Return defaultValue
End Function

Sub SaveStoredTextHeightMM(doc As Inventor.Document,
                           propertyName As String,
                           valueMM As Double)
    Try
        Dim ps As Inventor.PropertySet =
            doc.PropertySets.Item("Inventor User Defined Properties")

        Try
            Dim p As Inventor.Property = ps.Item(propertyName)
            p.Value = valueMM
        Catch
            ps.Add(valueMM, propertyName)
        End Try
    Catch
    End Try
End Sub

'============================================================
' Comment + text-height dialog
'============================================================
Function ShowLevelTextDialog(ByRef commentText As String,
                             ByRef textHeightMM As Double,
                             title As String) As Boolean

    Using frm As New System.Windows.Forms.Form()

        frm.Text = title
        frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        frm.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        frm.MaximizeBox = False
        frm.MinimizeBox = False
        frm.ShowInTaskbar = False
        frm.Width = 490
        frm.Height = 255

        Dim lblComment As New System.Windows.Forms.Label()
        lblComment.AutoSize = True
        lblComment.SetBounds(15, 15, 430, 40)
        lblComment.Text =
            "コメントを入力してください。" & vbCrLf &
            "例：PUMP ROOT / FRAME TOP / PIPE C.L."
        frm.Controls.Add(lblComment)

        Dim txtComment As New System.Windows.Forms.TextBox()
        txtComment.SetBounds(18, 65, 430, 27)
        txtComment.Text = commentText
        frm.Controls.Add(txtComment)

        Dim lblHeight As New System.Windows.Forms.Label()
        lblHeight.AutoSize = True
        lblHeight.SetBounds(18, 112, 110, 25)
        lblHeight.Text = "文字高さ (mm)："
        frm.Controls.Add(lblHeight)

        Dim numHeight As New System.Windows.Forms.NumericUpDown()
        numHeight.SetBounds(135, 108, 100, 27)
        numHeight.DecimalPlaces = 1
        numHeight.Increment = 1D
        numHeight.Minimum = 1D
        numHeight.Maximum = 500D

        Dim startValue As Decimal = 10D
        Try
            startValue = CDec(textHeightMM)
        Catch
        End Try

        If startValue < numHeight.Minimum Then startValue = numHeight.Minimum
        If startValue > numHeight.Maximum Then startValue = numHeight.Maximum
        numHeight.Value = startValue
        frm.Controls.Add(numHeight)

        Dim lblKeep As New System.Windows.Forms.Label()
        lblKeep.AutoSize = True
        lblKeep.SetBounds(250, 112, 180, 25)
        lblKeep.Text = "※ 次回もこの値を使用"
        frm.Controls.Add(lblKeep)

        Dim btnOK As New System.Windows.Forms.Button()
        btnOK.Text = "OK"
        btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        btnOK.SetBounds(285, 160, 75, 30)
        frm.Controls.Add(btnOK)

        Dim btnCancel As New System.Windows.Forms.Button()
        btnCancel.Text = "キャンセル"
        btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        btnCancel.SetBounds(373, 160, 75, 30)
        frm.Controls.Add(btnCancel)

        frm.AcceptButton = btnOK
        frm.CancelButton = btnCancel

        Dim result As System.Windows.Forms.DialogResult = frm.ShowDialog()
        If result <> System.Windows.Forms.DialogResult.OK Then Return False

        commentText = txtComment.Text.Trim()
        textHeightMM = CDbl(numHeight.Value)
        Return True
    End Using
End Function

'============================================================
' Select a planar face and capture the exact 3D position of the
' graphics-window click projected onto the selected face.
'
' InteractionEvents.SelectEvents.OnSelect supplies ModelPosition.
' ESC terminates InteractionEvents and returns Nothing.
'============================================================
Class PlanarFacePointPicker

    Private mApp As Inventor.Application
    Private mInteraction As Inventor.InteractionEvents
    Private mSelectEvents As Inventor.SelectEvents
    Private mStillSelecting As Boolean
    Private mSelectedObject As Object
    Private mClickPoint As Inventor.Point

    Public Sub New(app As Inventor.Application)
        mApp = app
    End Sub

    Public Function Pick(filter As Inventor.SelectionFilterEnum,
                         prompt As String,
                         ByRef modelClickPoint As Inventor.Point) As Object

        mSelectedObject = Nothing
        mClickPoint = Nothing
        modelClickPoint = Nothing
        mStillSelecting = True

        Try
            mInteraction = mApp.CommandManager.CreateInteractionEvents()
            mSelectEvents = mInteraction.SelectEvents

            mSelectEvents.AddSelectionFilter(filter)
            mInteraction.StatusBarText = prompt

            AddHandler mSelectEvents.OnSelect, AddressOf SelectEvents_OnSelect
            AddHandler mInteraction.OnTerminate, AddressOf InteractionEvents_OnTerminate

            mInteraction.Start()

            Do While mStillSelecting
                mApp.UserInterfaceManager.DoEvents()
                System.Threading.Thread.Sleep(20)
            Loop

        Finally
            Try
                If mInteraction IsNot Nothing Then
                    mInteraction.Stop()
                End If
            Catch
            End Try

            If mSelectEvents IsNot Nothing Then
                RemoveHandler mSelectEvents.OnSelect, AddressOf SelectEvents_OnSelect
            End If

            If mInteraction IsNot Nothing Then
                RemoveHandler mInteraction.OnTerminate, AddressOf InteractionEvents_OnTerminate
            End If
        End Try

        If mClickPoint IsNot Nothing Then
            modelClickPoint = mClickPoint.Copy()
        End If

        Return mSelectedObject
    End Function

    Private Sub SelectEvents_OnSelect(
        JustSelectedEntities As Inventor.ObjectsEnumerator,
        SelectionDevice As Inventor.SelectionDeviceEnum,
        ModelPosition As Inventor.Point,
        ViewPosition As Inventor.Point2d,
        View As Inventor.View)

        If JustSelectedEntities Is Nothing OrElse JustSelectedEntities.Count = 0 Then
            Return
        End If

        ' The click position is meaningful only for a pick in the graphics window.
        If SelectionDevice <> Inventor.SelectionDeviceEnum.kGraphicsWindowSelection Then
            Return
        End If

        mSelectedObject = JustSelectedEntities.Item(1)

        If ModelPosition IsNot Nothing Then
            mClickPoint = ModelPosition.Copy()
        End If

        mStillSelecting = False
    End Sub

    Private Sub InteractionEvents_OnTerminate()
        mStillSelecting = False
    End Sub

End Class


'============================================================
' Return assembly-context Plane from selected planar entity.
'============================================================
Function GetPlane(selObj As Object) As Inventor.Plane
    Try
        If TypeOf selObj Is Inventor.FaceProxy Then
            Dim fp As Inventor.FaceProxy = CType(selObj, Inventor.FaceProxy)
            Return CType(fp.Geometry, Inventor.Plane)
        ElseIf TypeOf selObj Is Inventor.Face Then
            Dim f As Inventor.Face = CType(selObj, Inventor.Face)
            Return CType(f.Geometry, Inventor.Plane)
        ElseIf TypeOf selObj Is Inventor.WorkPlaneProxy Then
            Dim wp As Inventor.WorkPlaneProxy = CType(selObj, Inventor.WorkPlaneProxy)
            Return wp.Plane
        ElseIf TypeOf selObj Is Inventor.WorkPlane Then
            Dim wp As Inventor.WorkPlane = CType(selObj, Inventor.WorkPlane)
            Return wp.Plane
        End If
    Catch
    End Try

    Return Nothing
End Function


'============================================================
' Return center of selected planar face RangeBox.
'============================================================
Function GetFaceCenterPoint(selObj As Object, app As Inventor.Application) As Inventor.Point
    Try
        Dim box As Inventor.Box = Nothing

        If TypeOf selObj Is Inventor.FaceProxy Then
            box = CType(selObj, Inventor.FaceProxy).RangeBox
        ElseIf TypeOf selObj Is Inventor.Face Then
            box = CType(selObj, Inventor.Face).RangeBox
        Else
            Return Nothing
        End If

        Return app.TransientGeometry.CreatePoint(
            (box.MinPoint.X + box.MaxPoint.X) / 2.0,
            (box.MinPoint.Y + box.MaxPoint.Y) / 2.0,
            (box.MinPoint.Z + box.MaxPoint.Z) / 2.0)

    Catch
        Return Nothing
    End Try
End Function


'============================================================
' Format FL level string.
'============================================================
Function FormatLevel(levelMm As Double, digits As Integer) As String
    Dim fmt As String

    If digits <= 0 Then
        fmt = "0"
    Else
        fmt = "0." & New String("0"c, digits)
    End If

    If Math.Abs(levelMm) < Math.Pow(10, -Math.Max(digits, 0)) / 2.0 Then
        Return "FL ±0"
    ElseIf levelMm > 0 Then
        Return "FL + " & levelMm.ToString(fmt) & " mm"
    Else
        Return "FL - " & Math.Abs(levelMm).ToString(fmt) & " mm"
    End If
End Function


'============================================================
' Make safe sketch name.
'============================================================
Function MakeSafeName(s As String) As String
    If String.IsNullOrWhiteSpace(s) Then Return ""

    Dim t As String = s.Trim()
    Dim badChars() As Char = {"\"c, "/"c, ":"c, "*"c, "?"c, ChrW(34), "<"c, ">"c, "|"c}

    For Each c As Char In badChars
        t = t.Replace(c, "_"c)
    Next

    If t.Length > 30 Then t = t.Substring(0, 30)
    Return t
End Function


'============================================================
' Avoid duplicate sketch names.
'============================================================
Function GetUniqueSketchName(def As Inventor.AssemblyComponentDefinition, baseName As String) As String
    Dim candidate As String = baseName
    Dim suffix As Integer = 1

    Do
        Dim exists As Boolean = False

        For Each sk As Inventor.PlanarSketch In def.Sketches
            If String.Equals(sk.Name, candidate, StringComparison.OrdinalIgnoreCase) Then
                exists = True
                Exit For
            End If
        Next

        If Not exists Then Return candidate

        suffix += 1
        candidate = baseName & "_" & suffix.ToString()
    Loop
End Function


'============================================================
' Escape XML special characters for FormattedText.
'============================================================
Function EscapeXml(s As String) As String
    If s Is Nothing Then Return ""

    Return s.Replace("&", "&amp;") _
            .Replace("<", "&lt;") _
            .Replace(">", "&gt;") _
            .Replace(ChrW(34), "&quot;") _
            .Replace("'", "&apos;")
End Function
